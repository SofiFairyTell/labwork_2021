﻿
namespace lw_sm_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.route = new System.Windows.Forms.Label();
            this.btnStart = new System.Windows.Forms.Button();
            this.signal = new System.Windows.Forms.PictureBox();
            this.grProperties = new System.Windows.Forms.GroupBox();
            this.btnParettoOPT = new System.Windows.Forms.Button();
            this.btOp = new System.Windows.Forms.Button();
            this.btnExperiment = new System.Windows.Forms.Button();
            this.tbEcapcity = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cbRandomEcapacity = new System.Windows.Forms.CheckBox();
            this.cbRandom = new System.Windows.Forms.CheckBox();
            this.lbT1 = new System.Windows.Forms.Label();
            this.tbT1 = new System.Windows.Forms.TextBox();
            this.lbT2 = new System.Windows.Forms.Label();
            this.tbT2 = new System.Windows.Forms.TextBox();
            this.tbT3 = new System.Windows.Forms.TextBox();
            this.lbT3 = new System.Windows.Forms.Label();
            this.tbEpsilon = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbNumSignal = new System.Windows.Forms.TextBox();
            this.lbSignal = new System.Windows.Forms.Label();
            this.tbNumComp = new System.Windows.Forms.TextBox();
            this.lbNumComp = new System.Windows.Forms.Label();
            this.tbSpeed = new System.Windows.Forms.TrackBar();
            this.lbComp1 = new System.Windows.Forms.Label();
            this.lbComp2 = new System.Windows.Forms.Label();
            this.lbComp3 = new System.Windows.Forms.Label();
            this.logTable = new System.Windows.Forms.DataGridView();
            this.TimeArrive = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TimeArriv = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TimePrep = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TimeComp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NumComp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CapComp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PrepSign = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ActionData = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tbModel = new System.Windows.Forms.TabControl();
            this.tabModel = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.lbExper = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbPrepVisual = new System.Windows.Forms.Label();
            this.gbRoute = new System.Windows.Forms.GroupBox();
            this.signalRoutePC3_3 = new System.Windows.Forms.PictureBox();
            this.signalRoutePC3_2 = new System.Windows.Forms.PictureBox();
            this.signalRoutePC3_1 = new System.Windows.Forms.PictureBox();
            this.signalRoute2 = new System.Windows.Forms.PictureBox();
            this.signalRoutePC2_3 = new System.Windows.Forms.PictureBox();
            this.signalRoutePC2_1 = new System.Windows.Forms.PictureBox();
            this.signalRoutePC2_2 = new System.Windows.Forms.PictureBox();
            this.signalRoute1 = new System.Windows.Forms.PictureBox();
            this.gbPC = new System.Windows.Forms.GroupBox();
            this.signalPC3 = new System.Windows.Forms.PictureBox();
            this.signalPC2 = new System.Windows.Forms.PictureBox();
            this.signalPC1 = new System.Windows.Forms.PictureBox();
            this.signalRoute = new System.Windows.Forms.PictureBox();
            this.tabData = new System.Windows.Forms.TabPage();
            this.tabStat = new System.Windows.Forms.TabPage();
            this.lbExperiment = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.lbWait = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lbPSignal = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lbProd = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lbLostSignal = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lbOuterSignal = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.lbAllCapacity = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbPrepSignal = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbSignalCounter = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.tbEXP = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signal)).BeginInit();
            this.grProperties.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbSpeed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.logTable)).BeginInit();
            this.tbModel.SuspendLayout();
            this.tabModel.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.gbRoute.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.signalRoutePC3_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signalRoutePC3_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signalRoutePC3_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signalRoute2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signalRoutePC2_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signalRoutePC2_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signalRoutePC2_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signalRoute1)).BeginInit();
            this.gbPC.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.signalPC3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signalPC2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signalPC1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.signalRoute)).BeginInit();
            this.tabData.SuspendLayout();
            this.tabStat.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::lw_sm_1.Properties.Resources.comp;
            this.pictureBox1.Location = new System.Drawing.Point(58, 20);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(138, 91);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::lw_sm_1.Properties.Resources.comp;
            this.pictureBox2.Location = new System.Drawing.Point(58, 115);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(138, 92);
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::lw_sm_1.Properties.Resources.comp;
            this.pictureBox3.Location = new System.Drawing.Point(58, 211);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(138, 92);
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // route
            // 
            this.route.AutoSize = true;
            this.route.BackColor = System.Drawing.Color.YellowGreen;
            this.route.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.route.Location = new System.Drawing.Point(49, 35);
            this.route.Name = "route";
            this.route.Size = new System.Drawing.Size(62, 25);
            this.route.TabIndex = 3;
            this.route.Text = "канал";
            // 
            // btnStart
            // 
            this.btnStart.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnStart.FlatAppearance.BorderSize = 5;
            this.btnStart.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Lime;
            this.btnStart.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Blue;
            this.btnStart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStart.Location = new System.Drawing.Point(131, 318);
            this.btnStart.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(117, 33);
            this.btnStart.TabIndex = 4;
            this.btnStart.Text = "Моделирование";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // signal
            // 
            this.signal.BackColor = System.Drawing.Color.Maroon;
            this.signal.Location = new System.Drawing.Point(15, 150);
            this.signal.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.signal.Name = "signal";
            this.signal.Size = new System.Drawing.Size(37, 36);
            this.signal.TabIndex = 5;
            this.signal.TabStop = false;
            this.signal.Visible = false;
            // 
            // grProperties
            // 
            this.grProperties.Controls.Add(this.label17);
            this.grProperties.Controls.Add(this.tbEXP);
            this.grProperties.Controls.Add(this.btnParettoOPT);
            this.grProperties.Controls.Add(this.btOp);
            this.grProperties.Controls.Add(this.btnExperiment);
            this.grProperties.Controls.Add(this.tbEcapcity);
            this.grProperties.Controls.Add(this.label15);
            this.grProperties.Controls.Add(this.groupBox3);
            this.grProperties.Controls.Add(this.tbEpsilon);
            this.grProperties.Controls.Add(this.label4);
            this.grProperties.Controls.Add(this.tbNumSignal);
            this.grProperties.Controls.Add(this.lbSignal);
            this.grProperties.Controls.Add(this.btnStart);
            this.grProperties.Controls.Add(this.tbNumComp);
            this.grProperties.Controls.Add(this.lbNumComp);
            this.grProperties.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.grProperties.Location = new System.Drawing.Point(829, 4);
            this.grProperties.Name = "grProperties";
            this.grProperties.Size = new System.Drawing.Size(351, 396);
            this.grProperties.TabIndex = 6;
            this.grProperties.TabStop = false;
            this.grProperties.Text = "Параметры моделирования";
            // 
            // btnParettoOPT
            // 
            this.btnParettoOPT.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnParettoOPT.FlatAppearance.BorderSize = 5;
            this.btnParettoOPT.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Lime;
            this.btnParettoOPT.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Blue;
            this.btnParettoOPT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnParettoOPT.Location = new System.Drawing.Point(132, 355);
            this.btnParettoOPT.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnParettoOPT.Name = "btnParettoOPT";
            this.btnParettoOPT.Size = new System.Drawing.Size(116, 33);
            this.btnParettoOPT.TabIndex = 25;
            this.btnParettoOPT.Text = "Оптимизация ";
            this.btnParettoOPT.UseVisualStyleBackColor = true;
            this.btnParettoOPT.Click += new System.EventHandler(this.btnParettoOPT_Click);
            // 
            // btOp
            // 
            this.btOp.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btOp.FlatAppearance.BorderSize = 5;
            this.btOp.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Lime;
            this.btOp.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Blue;
            this.btOp.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btOp.Location = new System.Drawing.Point(8, 355);
            this.btOp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btOp.Name = "btOp";
            this.btOp.Size = new System.Drawing.Size(116, 33);
            this.btOp.TabIndex = 24;
            this.btOp.Text = "Опыты (цикл)";
            this.btOp.UseVisualStyleBackColor = true;
            this.btOp.Click += new System.EventHandler(this.btOp_Click);
            // 
            // btnExperiment
            // 
            this.btnExperiment.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnExperiment.FlatAppearance.BorderSize = 5;
            this.btnExperiment.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Lime;
            this.btnExperiment.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Blue;
            this.btnExperiment.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnExperiment.Location = new System.Drawing.Point(8, 318);
            this.btnExperiment.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnExperiment.Name = "btnExperiment";
            this.btnExperiment.Size = new System.Drawing.Size(117, 33);
            this.btnExperiment.TabIndex = 23;
            this.btnExperiment.Text = "Эксперимент";
            this.btnExperiment.UseVisualStyleBackColor = true;
            this.btnExperiment.Click += new System.EventHandler(this.btnExperiment_Click);
            // 
            // tbEcapcity
            // 
            this.tbEcapcity.Location = new System.Drawing.Point(138, 136);
            this.tbEcapcity.Name = "tbEcapcity";
            this.tbEcapcity.Size = new System.Drawing.Size(70, 23);
            this.tbEcapcity.TabIndex = 22;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(6, 136);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(118, 15);
            this.label15.TabIndex = 21;
            this.label15.Text = "Ёмкость очереди (E)";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.groupBox2);
            this.groupBox3.Controls.Add(this.lbT1);
            this.groupBox3.Controls.Add(this.tbT1);
            this.groupBox3.Controls.Add(this.lbT2);
            this.groupBox3.Controls.Add(this.tbT2);
            this.groupBox3.Controls.Add(this.tbT3);
            this.groupBox3.Controls.Add(this.lbT3);
            this.groupBox3.Location = new System.Drawing.Point(7, 169);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(338, 144);
            this.groupBox3.TabIndex = 20;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Время обработки на каждом этапе";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cbRandomEcapacity);
            this.groupBox2.Controls.Add(this.cbRandom);
            this.groupBox2.Location = new System.Drawing.Point(6, 24);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(326, 62);
            this.groupBox2.TabIndex = 19;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Генерация ";
            // 
            // cbRandomEcapacity
            // 
            this.cbRandomEcapacity.AutoSize = true;
            this.cbRandomEcapacity.Location = new System.Drawing.Point(118, 25);
            this.cbRandomEcapacity.Name = "cbRandomEcapacity";
            this.cbRandomEcapacity.Size = new System.Drawing.Size(149, 19);
            this.cbRandomEcapacity.TabIndex = 18;
            this.cbRandomEcapacity.Text = "случайная ёмкость (Е)";
            this.cbRandomEcapacity.UseVisualStyleBackColor = true;
            this.cbRandomEcapacity.CheckedChanged += new System.EventHandler(this.cbRandomEcapcity_CheckedChanged);
            // 
            // cbRandom
            // 
            this.cbRandom.AutoSize = true;
            this.cbRandom.Location = new System.Drawing.Point(26, 25);
            this.cbRandom.Name = "cbRandom";
            this.cbRandom.Size = new System.Drawing.Size(86, 19);
            this.cbRandom.TabIndex = 17;
            this.cbRandom.Text = "t случайно";
            this.cbRandom.UseVisualStyleBackColor = true;
            this.cbRandom.CheckedChanged += new System.EventHandler(this.cbRandom_CheckedChanged);
            // 
            // lbT1
            // 
            this.lbT1.AutoSize = true;
            this.lbT1.Location = new System.Drawing.Point(15, 106);
            this.lbT1.Name = "lbT1";
            this.lbT1.Size = new System.Drawing.Size(17, 15);
            this.lbT1.TabIndex = 7;
            this.lbT1.Text = "t1";
            // 
            // tbT1
            // 
            this.tbT1.Location = new System.Drawing.Point(47, 106);
            this.tbT1.Name = "tbT1";
            this.tbT1.Size = new System.Drawing.Size(41, 23);
            this.tbT1.TabIndex = 8;
            // 
            // lbT2
            // 
            this.lbT2.AutoSize = true;
            this.lbT2.Location = new System.Drawing.Point(104, 109);
            this.lbT2.Name = "lbT2";
            this.lbT2.Size = new System.Drawing.Size(17, 15);
            this.lbT2.TabIndex = 9;
            this.lbT2.Text = "t2";
            // 
            // tbT2
            // 
            this.tbT2.Location = new System.Drawing.Point(127, 106);
            this.tbT2.Name = "tbT2";
            this.tbT2.Size = new System.Drawing.Size(41, 23);
            this.tbT2.TabIndex = 10;
            // 
            // tbT3
            // 
            this.tbT3.Location = new System.Drawing.Point(207, 106);
            this.tbT3.Name = "tbT3";
            this.tbT3.Size = new System.Drawing.Size(41, 23);
            this.tbT3.TabIndex = 12;
            // 
            // lbT3
            // 
            this.lbT3.AutoSize = true;
            this.lbT3.Location = new System.Drawing.Point(184, 109);
            this.lbT3.Name = "lbT3";
            this.lbT3.Size = new System.Drawing.Size(17, 15);
            this.lbT3.TabIndex = 11;
            this.lbT3.Text = "t3";
            // 
            // tbEpsilon
            // 
            this.tbEpsilon.Location = new System.Drawing.Point(138, 98);
            this.tbEpsilon.Name = "tbEpsilon";
            this.tbEpsilon.Size = new System.Drawing.Size(70, 23);
            this.tbEpsilon.TabIndex = 16;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 106);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 15);
            this.label4.TabIndex = 15;
            this.label4.Text = "Точность";
            // 
            // tbNumSignal
            // 
            this.tbNumSignal.Location = new System.Drawing.Point(138, 61);
            this.tbNumSignal.Name = "tbNumSignal";
            this.tbNumSignal.Size = new System.Drawing.Size(70, 23);
            this.tbNumSignal.TabIndex = 14;
            // 
            // lbSignal
            // 
            this.lbSignal.AutoSize = true;
            this.lbSignal.Location = new System.Drawing.Point(7, 56);
            this.lbSignal.Name = "lbSignal";
            this.lbSignal.Size = new System.Drawing.Size(88, 45);
            this.lbSignal.TabIndex = 13;
            this.lbSignal.Text = "N_сигналов\r\nдля обработки\r\nв ЭВМ";
            // 
            // tbNumComp
            // 
            this.tbNumComp.Location = new System.Drawing.Point(138, 27);
            this.tbNumComp.Name = "tbNumComp";
            this.tbNumComp.Size = new System.Drawing.Size(70, 23);
            this.tbNumComp.TabIndex = 6;
            // 
            // lbNumComp
            // 
            this.lbNumComp.AutoSize = true;
            this.lbNumComp.Location = new System.Drawing.Point(7, 30);
            this.lbNumComp.Name = "lbNumComp";
            this.lbNumComp.Size = new System.Drawing.Size(97, 15);
            this.lbNumComp.TabIndex = 5;
            this.lbNumComp.Text = "N_компьютеров";
            // 
            // tbSpeed
            // 
            this.tbSpeed.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.tbSpeed.Cursor = System.Windows.Forms.Cursors.Default;
            this.tbSpeed.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.tbSpeed.Location = new System.Drawing.Point(0, 421);
            this.tbSpeed.Maximum = 30;
            this.tbSpeed.Name = "tbSpeed";
            this.tbSpeed.Size = new System.Drawing.Size(1192, 45);
            this.tbSpeed.SmallChange = 10;
            this.tbSpeed.TabIndex = 17;
            this.tbSpeed.TickFrequency = 10;
            this.tbSpeed.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.tbSpeed.Value = 10;
            this.tbSpeed.Scroll += new System.EventHandler(this.tbSpeed_Scroll);
            // 
            // lbComp1
            // 
            this.lbComp1.AutoSize = true;
            this.lbComp1.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbComp1.Location = new System.Drawing.Point(17, 46);
            this.lbComp1.Name = "lbComp1";
            this.lbComp1.Size = new System.Drawing.Size(22, 25);
            this.lbComp1.TabIndex = 7;
            this.lbComp1.Text = "0";
            // 
            // lbComp2
            // 
            this.lbComp2.AutoSize = true;
            this.lbComp2.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbComp2.Location = new System.Drawing.Point(17, 156);
            this.lbComp2.Name = "lbComp2";
            this.lbComp2.Size = new System.Drawing.Size(22, 25);
            this.lbComp2.TabIndex = 8;
            this.lbComp2.Text = "0";
            // 
            // lbComp3
            // 
            this.lbComp3.AutoSize = true;
            this.lbComp3.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbComp3.Location = new System.Drawing.Point(17, 255);
            this.lbComp3.Name = "lbComp3";
            this.lbComp3.Size = new System.Drawing.Size(22, 25);
            this.lbComp3.TabIndex = 9;
            this.lbComp3.Text = "0";
            // 
            // logTable
            // 
            this.logTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.logTable.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.TimeArrive,
            this.TimeArriv,
            this.TimePrep,
            this.TimeComp,
            this.NumComp,
            this.CapComp,
            this.PrepSign,
            this.ActionData});
            this.logTable.Location = new System.Drawing.Point(6, 6);
            this.logTable.Name = "logTable";
            this.logTable.RowTemplate.Height = 25;
            this.logTable.Size = new System.Drawing.Size(794, 337);
            this.logTable.TabIndex = 10;
            // 
            // TimeArrive
            // 
            this.TimeArrive.HeaderText = "t0";
            this.TimeArrive.Name = "TimeArrive";
            // 
            // TimeArriv
            // 
            this.TimeArriv.HeaderText = "Вр.приб";
            this.TimeArriv.Name = "TimeArriv";
            this.TimeArriv.Visible = false;
            // 
            // TimePrep
            // 
            this.TimePrep.HeaderText = "Вр.Канал";
            this.TimePrep.Name = "TimePrep";
            this.TimePrep.Visible = false;
            // 
            // TimeComp
            // 
            this.TimeComp.HeaderText = "Вр.ЭВМ";
            this.TimeComp.Name = "TimeComp";
            this.TimeComp.Visible = false;
            // 
            // NumComp
            // 
            this.NumComp.HeaderText = "№ЭВМ (занятого обработкой сигнала)";
            this.NumComp.Name = "NumComp";
            // 
            // CapComp
            // 
            this.CapComp.HeaderText = "Емк.ЭВМ";
            this.CapComp.Name = "CapComp";
            // 
            // PrepSign
            // 
            this.PrepSign.HeaderText = "Кол-во обработанных сигналов";
            this.PrepSign.Name = "PrepSign";
            // 
            // ActionData
            // 
            this.ActionData.HeaderText = "Вып.действие";
            this.ActionData.Name = "ActionData";
            // 
            // tbModel
            // 
            this.tbModel.Controls.Add(this.tabModel);
            this.tbModel.Controls.Add(this.tabData);
            this.tbModel.Controls.Add(this.tabStat);
            this.tbModel.Location = new System.Drawing.Point(13, 22);
            this.tbModel.Name = "tbModel";
            this.tbModel.SelectedIndex = 0;
            this.tbModel.Size = new System.Drawing.Size(810, 367);
            this.tbModel.TabIndex = 11;
            // 
            // tabModel
            // 
            this.tabModel.Controls.Add(this.groupBox4);
            this.tabModel.Controls.Add(this.groupBox1);
            this.tabModel.Controls.Add(this.gbRoute);
            this.tabModel.Controls.Add(this.signalRoutePC3_3);
            this.tabModel.Controls.Add(this.signalRoutePC3_2);
            this.tabModel.Controls.Add(this.signalRoutePC3_1);
            this.tabModel.Controls.Add(this.signalRoute2);
            this.tabModel.Controls.Add(this.signalRoutePC2_3);
            this.tabModel.Controls.Add(this.signalRoutePC2_1);
            this.tabModel.Controls.Add(this.signalRoutePC2_2);
            this.tabModel.Controls.Add(this.signalRoute1);
            this.tabModel.Controls.Add(this.gbPC);
            this.tabModel.Controls.Add(this.signalPC3);
            this.tabModel.Controls.Add(this.signalPC2);
            this.tabModel.Controls.Add(this.signalPC1);
            this.tabModel.Controls.Add(this.signalRoute);
            this.tabModel.Controls.Add(this.signal);
            this.tabModel.Location = new System.Drawing.Point(4, 24);
            this.tabModel.Name = "tabModel";
            this.tabModel.Padding = new System.Windows.Forms.Padding(3);
            this.tabModel.Size = new System.Drawing.Size(802, 339);
            this.tabModel.TabIndex = 0;
            this.tabModel.Text = "Модель";
            this.tabModel.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.YellowGreen;
            this.groupBox4.Controls.Add(this.lbExper);
            this.groupBox4.Location = new System.Drawing.Point(693, 250);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(103, 58);
            this.groupBox4.TabIndex = 28;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Эксперимент";
            // 
            // lbExper
            // 
            this.lbExper.AutoSize = true;
            this.lbExper.BackColor = System.Drawing.Color.YellowGreen;
            this.lbExper.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbExper.Location = new System.Drawing.Point(16, 24);
            this.lbExper.Name = "lbExper";
            this.lbExper.Size = new System.Drawing.Size(17, 19);
            this.lbExper.TabIndex = 3;
            this.lbExper.Text = "0";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.YellowGreen;
            this.groupBox1.Controls.Add(this.lbPrepVisual);
            this.groupBox1.Location = new System.Drawing.Point(693, 121);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(103, 101);
            this.groupBox1.TabIndex = 27;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Обработано";
            // 
            // lbPrepVisual
            // 
            this.lbPrepVisual.AutoSize = true;
            this.lbPrepVisual.BackColor = System.Drawing.Color.YellowGreen;
            this.lbPrepVisual.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lbPrepVisual.Location = new System.Drawing.Point(16, 30);
            this.lbPrepVisual.Name = "lbPrepVisual";
            this.lbPrepVisual.Size = new System.Drawing.Size(22, 25);
            this.lbPrepVisual.TabIndex = 3;
            this.lbPrepVisual.Text = "0";
            // 
            // gbRoute
            // 
            this.gbRoute.BackColor = System.Drawing.Color.YellowGreen;
            this.gbRoute.Controls.Add(this.route);
            this.gbRoute.Location = new System.Drawing.Point(59, 121);
            this.gbRoute.Name = "gbRoute";
            this.gbRoute.Size = new System.Drawing.Size(176, 101);
            this.gbRoute.TabIndex = 26;
            this.gbRoute.TabStop = false;
            this.gbRoute.Text = "Сигналов в канале:";
            // 
            // signalRoutePC3_3
            // 
            this.signalRoutePC3_3.BackColor = System.Drawing.Color.Gold;
            this.signalRoutePC3_3.Location = new System.Drawing.Point(339, 261);
            this.signalRoutePC3_3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.signalRoutePC3_3.Name = "signalRoutePC3_3";
            this.signalRoutePC3_3.Size = new System.Drawing.Size(24, 24);
            this.signalRoutePC3_3.TabIndex = 25;
            this.signalRoutePC3_3.TabStop = false;
            this.signalRoutePC3_3.Visible = false;
            // 
            // signalRoutePC3_2
            // 
            this.signalRoutePC3_2.BackColor = System.Drawing.Color.Gold;
            this.signalRoutePC3_2.Location = new System.Drawing.Point(283, 261);
            this.signalRoutePC3_2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.signalRoutePC3_2.Name = "signalRoutePC3_2";
            this.signalRoutePC3_2.Size = new System.Drawing.Size(24, 24);
            this.signalRoutePC3_2.TabIndex = 24;
            this.signalRoutePC3_2.TabStop = false;
            this.signalRoutePC3_2.Visible = false;
            // 
            // signalRoutePC3_1
            // 
            this.signalRoutePC3_1.BackColor = System.Drawing.Color.Gold;
            this.signalRoutePC3_1.Location = new System.Drawing.Point(241, 217);
            this.signalRoutePC3_1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.signalRoutePC3_1.Name = "signalRoutePC3_1";
            this.signalRoutePC3_1.Size = new System.Drawing.Size(24, 24);
            this.signalRoutePC3_1.TabIndex = 23;
            this.signalRoutePC3_1.TabStop = false;
            this.signalRoutePC3_1.Visible = false;
            // 
            // signalRoute2
            // 
            this.signalRoute2.BackColor = System.Drawing.Color.Gold;
            this.signalRoute2.Location = new System.Drawing.Point(283, 53);
            this.signalRoute2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.signalRoute2.Name = "signalRoute2";
            this.signalRoute2.Size = new System.Drawing.Size(24, 24);
            this.signalRoute2.TabIndex = 22;
            this.signalRoute2.TabStop = false;
            this.signalRoute2.Visible = false;
            // 
            // signalRoutePC2_3
            // 
            this.signalRoutePC2_3.BackColor = System.Drawing.Color.Gold;
            this.signalRoutePC2_3.Location = new System.Drawing.Point(339, 157);
            this.signalRoutePC2_3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.signalRoutePC2_3.Name = "signalRoutePC2_3";
            this.signalRoutePC2_3.Size = new System.Drawing.Size(24, 24);
            this.signalRoutePC2_3.TabIndex = 21;
            this.signalRoutePC2_3.TabStop = false;
            this.signalRoutePC2_3.Visible = false;
            // 
            // signalRoutePC2_1
            // 
            this.signalRoutePC2_1.BackColor = System.Drawing.Color.Gold;
            this.signalRoutePC2_1.Location = new System.Drawing.Point(241, 157);
            this.signalRoutePC2_1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.signalRoutePC2_1.Name = "signalRoutePC2_1";
            this.signalRoutePC2_1.Size = new System.Drawing.Size(24, 24);
            this.signalRoutePC2_1.TabIndex = 20;
            this.signalRoutePC2_1.TabStop = false;
            this.signalRoutePC2_1.Visible = false;
            // 
            // signalRoutePC2_2
            // 
            this.signalRoutePC2_2.BackColor = System.Drawing.Color.Gold;
            this.signalRoutePC2_2.Location = new System.Drawing.Point(292, 157);
            this.signalRoutePC2_2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.signalRoutePC2_2.Name = "signalRoutePC2_2";
            this.signalRoutePC2_2.Size = new System.Drawing.Size(24, 24);
            this.signalRoutePC2_2.TabIndex = 19;
            this.signalRoutePC2_2.TabStop = false;
            this.signalRoutePC2_2.Visible = false;
            // 
            // signalRoute1
            // 
            this.signalRoute1.BackColor = System.Drawing.Color.Gold;
            this.signalRoute1.Location = new System.Drawing.Point(241, 90);
            this.signalRoute1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.signalRoute1.Name = "signalRoute1";
            this.signalRoute1.Size = new System.Drawing.Size(24, 24);
            this.signalRoute1.TabIndex = 18;
            this.signalRoute1.TabStop = false;
            this.signalRoute1.Visible = false;
            // 
            // gbPC
            // 
            this.gbPC.BackColor = System.Drawing.Color.LightGray;
            this.gbPC.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.gbPC.Controls.Add(this.pictureBox1);
            this.gbPC.Controls.Add(this.pictureBox2);
            this.gbPC.Controls.Add(this.pictureBox3);
            this.gbPC.Controls.Add(this.lbComp1);
            this.gbPC.Controls.Add(this.lbComp2);
            this.gbPC.Controls.Add(this.lbComp3);
            this.gbPC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.gbPC.Location = new System.Drawing.Point(453, 6);
            this.gbPC.Name = "gbPC";
            this.gbPC.Size = new System.Drawing.Size(234, 322);
            this.gbPC.TabIndex = 17;
            this.gbPC.TabStop = false;
            this.gbPC.Text = "Компьютеры для обработки сигналов";
            // 
            // signalPC3
            // 
            this.signalPC3.BackColor = System.Drawing.Color.ForestGreen;
            this.signalPC3.Location = new System.Drawing.Point(383, 250);
            this.signalPC3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.signalPC3.Name = "signalPC3";
            this.signalPC3.Size = new System.Drawing.Size(37, 36);
            this.signalPC3.TabIndex = 13;
            this.signalPC3.TabStop = false;
            this.signalPC3.Visible = false;
            // 
            // signalPC2
            // 
            this.signalPC2.BackColor = System.Drawing.Color.ForestGreen;
            this.signalPC2.Location = new System.Drawing.Point(383, 151);
            this.signalPC2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.signalPC2.Name = "signalPC2";
            this.signalPC2.Size = new System.Drawing.Size(37, 36);
            this.signalPC2.TabIndex = 12;
            this.signalPC2.TabStop = false;
            this.signalPC2.Visible = false;
            // 
            // signalPC1
            // 
            this.signalPC1.BackColor = System.Drawing.Color.ForestGreen;
            this.signalPC1.Location = new System.Drawing.Point(383, 52);
            this.signalPC1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.signalPC1.Name = "signalPC1";
            this.signalPC1.Size = new System.Drawing.Size(37, 36);
            this.signalPC1.TabIndex = 11;
            this.signalPC1.TabStop = false;
            this.signalPC1.Visible = false;
            // 
            // signalRoute
            // 
            this.signalRoute.BackColor = System.Drawing.Color.Gold;
            this.signalRoute.Location = new System.Drawing.Point(339, 52);
            this.signalRoute.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.signalRoute.Name = "signalRoute";
            this.signalRoute.Size = new System.Drawing.Size(24, 24);
            this.signalRoute.TabIndex = 10;
            this.signalRoute.TabStop = false;
            this.signalRoute.Visible = false;
            // 
            // tabData
            // 
            this.tabData.Controls.Add(this.logTable);
            this.tabData.Location = new System.Drawing.Point(4, 24);
            this.tabData.Name = "tabData";
            this.tabData.Padding = new System.Windows.Forms.Padding(3);
            this.tabData.Size = new System.Drawing.Size(802, 339);
            this.tabData.TabIndex = 1;
            this.tabData.Text = "Данные";
            this.tabData.UseVisualStyleBackColor = true;
            // 
            // tabStat
            // 
            this.tabStat.Controls.Add(this.lbExperiment);
            this.tabStat.Controls.Add(this.label16);
            this.tabStat.Controls.Add(this.lbWait);
            this.tabStat.Controls.Add(this.label10);
            this.tabStat.Controls.Add(this.lbPSignal);
            this.tabStat.Controls.Add(this.label8);
            this.tabStat.Controls.Add(this.lbProd);
            this.tabStat.Controls.Add(this.label7);
            this.tabStat.Controls.Add(this.lbLostSignal);
            this.tabStat.Controls.Add(this.label6);
            this.tabStat.Controls.Add(this.lbOuterSignal);
            this.tabStat.Controls.Add(this.label5);
            this.tabStat.Controls.Add(this.lbAllCapacity);
            this.tabStat.Controls.Add(this.label3);
            this.tabStat.Controls.Add(this.lbPrepSignal);
            this.tabStat.Controls.Add(this.label2);
            this.tabStat.Controls.Add(this.lbSignalCounter);
            this.tabStat.Controls.Add(this.label1);
            this.tabStat.Location = new System.Drawing.Point(4, 24);
            this.tabStat.Name = "tabStat";
            this.tabStat.Padding = new System.Windows.Forms.Padding(3);
            this.tabStat.Size = new System.Drawing.Size(802, 339);
            this.tabStat.TabIndex = 2;
            this.tabStat.Text = "Статистика";
            this.tabStat.UseVisualStyleBackColor = true;
            // 
            // lbExperiment
            // 
            this.lbExperiment.AutoSize = true;
            this.lbExperiment.BackColor = System.Drawing.Color.Gold;
            this.lbExperiment.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbExperiment.Location = new System.Drawing.Point(483, 151);
            this.lbExperiment.Name = "lbExperiment";
            this.lbExperiment.Size = new System.Drawing.Size(13, 15);
            this.lbExperiment.TabIndex = 17;
            this.lbExperiment.Text = "0";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(282, 151);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(89, 15);
            this.label16.TabIndex = 16;
            this.label16.Text = "Эксперименты";
            // 
            // lbWait
            // 
            this.lbWait.AutoSize = true;
            this.lbWait.BackColor = System.Drawing.Color.Gold;
            this.lbWait.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbWait.Location = new System.Drawing.Point(483, 110);
            this.lbWait.Name = "lbWait";
            this.lbWait.Size = new System.Drawing.Size(13, 15);
            this.lbWait.TabIndex = 15;
            this.lbWait.Text = "0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(282, 110);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(192, 15);
            this.label10.TabIndex = 14;
            this.label10.Text = "Вероятность ожидания в очереди";
            // 
            // lbPSignal
            // 
            this.lbPSignal.AutoSize = true;
            this.lbPSignal.BackColor = System.Drawing.Color.Gold;
            this.lbPSignal.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbPSignal.Location = new System.Drawing.Point(483, 69);
            this.lbPSignal.Name = "lbPSignal";
            this.lbPSignal.Size = new System.Drawing.Size(13, 15);
            this.lbPSignal.TabIndex = 13;
            this.lbPSignal.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(282, 69);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(165, 15);
            this.label8.TabIndex = 12;
            this.label8.Text = "Вероятность потери сигнала";
            // 
            // lbProd
            // 
            this.lbProd.AutoSize = true;
            this.lbProd.BackColor = System.Drawing.Color.Gold;
            this.lbProd.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbProd.Location = new System.Drawing.Point(483, 30);
            this.lbProd.Name = "lbProd";
            this.lbProd.Size = new System.Drawing.Size(13, 15);
            this.lbProd.TabIndex = 11;
            this.lbProd.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(282, 30);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(174, 15);
            this.label7.TabIndex = 10;
            this.label7.Text = "Производительность системы";
            // 
            // lbLostSignal
            // 
            this.lbLostSignal.AutoSize = true;
            this.lbLostSignal.BackColor = System.Drawing.Color.Gold;
            this.lbLostSignal.Location = new System.Drawing.Point(217, 170);
            this.lbLostSignal.Name = "lbLostSignal";
            this.lbLostSignal.Size = new System.Drawing.Size(13, 15);
            this.lbLostSignal.TabIndex = 9;
            this.lbLostSignal.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 170);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(115, 15);
            this.label6.TabIndex = 8;
            this.label6.Text = "Потеряно сигналов";
            // 
            // lbOuterSignal
            // 
            this.lbOuterSignal.AutoSize = true;
            this.lbOuterSignal.BackColor = System.Drawing.Color.Gold;
            this.lbOuterSignal.Location = new System.Drawing.Point(217, 69);
            this.lbOuterSignal.Name = "lbOuterSignal";
            this.lbOuterSignal.Size = new System.Drawing.Size(13, 15);
            this.lbOuterSignal.TabIndex = 7;
            this.lbOuterSignal.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(16, 69);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(125, 15);
            this.label5.TabIndex = 6;
            this.label5.Text = "Обработано в канале";
            // 
            // lbAllCapacity
            // 
            this.lbAllCapacity.AutoSize = true;
            this.lbAllCapacity.BackColor = System.Drawing.Color.Gold;
            this.lbAllCapacity.Location = new System.Drawing.Point(217, 138);
            this.lbAllCapacity.Name = "lbAllCapacity";
            this.lbAllCapacity.Size = new System.Drawing.Size(13, 15);
            this.lbAllCapacity.TabIndex = 5;
            this.lbAllCapacity.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 138);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(121, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "Осталось в очередях";
            // 
            // lbPrepSignal
            // 
            this.lbPrepSignal.AutoSize = true;
            this.lbPrepSignal.BackColor = System.Drawing.Color.Gold;
            this.lbPrepSignal.Location = new System.Drawing.Point(217, 104);
            this.lbPrepSignal.Name = "lbPrepSignal";
            this.lbPrepSignal.Size = new System.Drawing.Size(13, 15);
            this.lbPrepSignal.TabIndex = 3;
            this.lbPrepSignal.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 104);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(112, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Обработано в ЭВМ";
            // 
            // lbSignalCounter
            // 
            this.lbSignalCounter.AutoSize = true;
            this.lbSignalCounter.BackColor = System.Drawing.Color.Gold;
            this.lbSignalCounter.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbSignalCounter.Location = new System.Drawing.Point(217, 30);
            this.lbSignalCounter.Name = "lbSignalCounter";
            this.lbSignalCounter.Size = new System.Drawing.Size(13, 15);
            this.lbSignalCounter.TabIndex = 1;
            this.lbSignalCounter.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Принято сигналов";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(391, 392);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(0, 15);
            this.label9.TabIndex = 18;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(391, 407);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(19, 15);
            this.label11.TabIndex = 19;
            this.label11.Text = "10";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(781, 403);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(19, 15);
            this.label12.TabIndex = 20;
            this.label12.Text = "50";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(1167, 403);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(25, 15);
            this.label13.TabIndex = 21;
            this.label13.Text = "100";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(12, 392);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(143, 15);
            this.label14.TabIndex = 22;
            this.label14.Text = "Шаг изменения времени";
            // 
            // tbEXP
            // 
            this.tbEXP.Location = new System.Drawing.Point(269, 27);
            this.tbEXP.Name = "tbEXP";
            this.tbEXP.Size = new System.Drawing.Size(70, 23);
            this.tbEXP.TabIndex = 26;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(214, 30);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(50, 15);
            this.label17.TabIndex = 27;
            this.label17.Text = "Опытов";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1192, 466);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.tbSpeed);
            this.Controls.Add(this.tbModel);
            this.Controls.Add(this.grProperties);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Моделирование обработки сигналов";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signal)).EndInit();
            this.grProperties.ResumeLayout(false);
            this.grProperties.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tbSpeed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.logTable)).EndInit();
            this.tbModel.ResumeLayout(false);
            this.tabModel.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.gbRoute.ResumeLayout(false);
            this.gbRoute.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.signalRoutePC3_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signalRoutePC3_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signalRoutePC3_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signalRoute2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signalRoutePC2_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signalRoutePC2_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signalRoutePC2_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signalRoute1)).EndInit();
            this.gbPC.ResumeLayout(false);
            this.gbPC.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.signalPC3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signalPC2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signalPC1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.signalRoute)).EndInit();
            this.tabData.ResumeLayout(false);
            this.tabStat.ResumeLayout(false);
            this.tabStat.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label route;
        private System.Windows.Forms.PictureBox signal;
        private System.Windows.Forms.GroupBox grProperties;
        private System.Windows.Forms.Label lbComp1;
        private System.Windows.Forms.Label lbComp2;
        private System.Windows.Forms.Label lbComp3;
        private System.Windows.Forms.DataGridView logTable;
        private System.Windows.Forms.Label lbNumComp;
        private System.Windows.Forms.TabControl tbModel;
        private System.Windows.Forms.TabPage tabModel;
        private System.Windows.Forms.TabPage tabData;
        private System.Windows.Forms.TabPage tabStat;
        private System.Windows.Forms.Label lbSignalCounter;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbPrepSignal;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbAllCapacity;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbOuterSignal;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbSignal;
        private System.Windows.Forms.Label lbLostSignal;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lbProd;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbPSignal;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbWait;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox signalPC3;
        private System.Windows.Forms.PictureBox signalPC2;
        private System.Windows.Forms.PictureBox signalPC1;
        private System.Windows.Forms.PictureBox signalRoute;
        private System.Windows.Forms.PictureBox signalRoutePC3_3;
        private System.Windows.Forms.PictureBox signalRoutePC3_2;
        private System.Windows.Forms.PictureBox signalRoutePC3_1;
        private System.Windows.Forms.PictureBox signalRoute2;
        private System.Windows.Forms.PictureBox signalRoutePC2_3;
        private System.Windows.Forms.PictureBox signalRoutePC2_1;
        private System.Windows.Forms.PictureBox signalRoutePC2_2;
        private System.Windows.Forms.PictureBox signalRoute1;
        private System.Windows.Forms.GroupBox gbPC;
        public System.Windows.Forms.TrackBar tbSpeed;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox gbRoute;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lbPrepVisual;
        private System.Windows.Forms.DataGridViewTextBoxColumn TimeArrive;
        private System.Windows.Forms.DataGridViewTextBoxColumn TimeArriv;
        private System.Windows.Forms.DataGridViewTextBoxColumn TimePrep;
        private System.Windows.Forms.DataGridViewTextBoxColumn TimeComp;
        private System.Windows.Forms.DataGridViewTextBoxColumn NumComp;
        private System.Windows.Forms.DataGridViewTextBoxColumn CapComp;
        private System.Windows.Forms.DataGridViewTextBoxColumn PrepSign;
        private System.Windows.Forms.DataGridViewTextBoxColumn ActionData;
        private System.Windows.Forms.Label lbT3;
        private System.Windows.Forms.Label lbT2;
        private System.Windows.Forms.Label lbT1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label15;
        public System.Windows.Forms.Button btnStart;
        public System.Windows.Forms.TextBox tbNumComp;
        public System.Windows.Forms.TextBox tbNumSignal;
        public System.Windows.Forms.TextBox tbEpsilon;
        public System.Windows.Forms.CheckBox cbRandom;
        public System.Windows.Forms.TextBox tbT3;
        public System.Windows.Forms.TextBox tbT2;
        public System.Windows.Forms.TextBox tbT1;
        public System.Windows.Forms.CheckBox cbRandomEcapacity;
        public System.Windows.Forms.TextBox tbEcapcity;
        public System.Windows.Forms.Button btnExperiment;
        private System.Windows.Forms.Label lbExperiment;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label lbExper;
        public System.Windows.Forms.Button btOp;
        public System.Windows.Forms.Button btnParettoOPT;
        private System.Windows.Forms.Label label17;
        public System.Windows.Forms.TextBox tbEXP;
    }
}